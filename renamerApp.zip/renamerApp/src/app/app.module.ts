import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';


import { AppComponent } from './app.component';
import { RenamerComponent } from './renamer/renamer.component';
import { FileUploaderService } from './file-uploader-service';



@NgModule({
  declarations: [
    AppComponent,
    RenamerComponent
  ],
  imports: [
	  HttpModule,
	  BrowserModule
  ],
  providers: [FileUploaderService],
  bootstrap: [AppComponent]
})
export class AppModule { }

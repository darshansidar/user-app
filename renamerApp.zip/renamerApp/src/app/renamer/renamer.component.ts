import { Component, OnInit,ElementRef } from '@angular/core';
import { FileUploaderService } from '../file-uploader-service';

@Component({
  selector: 'app-renamer',
  templateUrl: './renamer.component.html',
  styleUrls: ['./renamer.component.css']
})
export class RenamerComponent implements OnInit {

	
	constructor(public FileUploader:FileUploaderService) {
	}

  ngOnInit() {
  }

	files:any;
	getFilesList() {

		this.FileUploader.getFilesList()
			.then(data => {
				this.files = data;
				console.log("This is getUser method has called...", this.files);
			});
		// console.log("This is getUser method has called...", this.users);
	}

	filesPicked(getfiles) {
		this.files = new Array(); 
		console.log("start",getfiles);
    for (let i = 0; i < getfiles.length; i++) {
    	// for (let i = 0; i < fs.length; i++) {
			var f = getfiles[i];
			if (f.name.endsWith('.jpg') || f.name.endsWith('.jpeg') || f.name.endsWith('.png')) {
				this.files.push(f);
				
			}
		}

	 for (let i = 0; i < this.files.length; i++) {

			var file = this.files[i];
			var reader = new FileReader();
			reader.onload = function (fre:any) {
				var srcData = fre.currentTarget.result;
				console.log("srcData====",srcData);
				// console.log("reader.onload");
				// addThumbnail(srcData, i);
			};
			reader.readAsDataURL(file);
		}
    }

}




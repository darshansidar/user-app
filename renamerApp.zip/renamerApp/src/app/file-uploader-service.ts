import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class FileUploaderService {

	constructor(public http: Http) {
		console.log('Hello Restapi Provider');
	}


	data: any;
	// apiUrl = 'https://s3.ap-south-1.amazonaws.com/singularium-bde/templateData.csv';
	apiUrl:any = ["a345345, DF, 1",
"a568787, PG, 1"]
	// apiUrl = 'https://jsonplaceholder.typicode.com'

	
 public filterCSVData(apiUrl) {
	 console.log("apiUrl====", apiUrl);
	 var csv_data = apiUrl.toString().split(/\r?\n|\r/);
				console.log("csv_data===", csv_data);
				var myMap = new Map();


				for (var count = 0; count < csv_data.length; count++) {
					var cell_data = csv_data[count].split(",");
					console.log("cell_data===", cell_data);
					var key = cell_data[0];
					var value = cell_data[1];

					if (myMap.get(key)) {
						var arr = myMap.get(key);
						arr.push(value);

					} else {
						var arr:any = new Array(); 
						arr.push(value);
						myMap.set(key, arr);

					}

					console.log('hi' + myMap);
				}
				// var arr = myMap.get()
				// for (var i = 0; i < arr.length; i++) {
				// 	table_data += '<span class=span-clk data-index=' + i + ' id=' + i + '> ' + arr[i] + '</span>';
				// 	console.log("ppp", table_data);
				// }
				// // table_data += '</div>';
				// $('.bo-hints').html(table_data);

			}

	public getFilesList() {
		console.log("getFilesList method has called...", this.apiUrl);
	    var data =	this.filterCSVData(this.apiUrl);
		console.log("data====", data);
		if (this.data) {
			return Promise.resolve(this.data);
		}

		return new Promise(resolve => {
			this.http.get(this.apiUrl + '/templateData.csv')
				.map(res => res.json())
				.subscribe(data => {
					this.data = data;
					resolve(this.data);
				});
		});


	}
}

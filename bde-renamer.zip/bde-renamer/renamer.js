var files;
var selFile;
var imgId;
var selectedImage;
var templateData;
var imgFileName;
var img;
var templateDataPath = 'https://s3.ap-south-1.amazonaws.com/singularium-bde/templateData.csv';
// var templateDataPath = 'templateData.csv';

///////////////////////
////   FUNCTIONS   ////
///////////////////////

function readFiles(evt) {
	let fs = evt.target.files;
	files = [];
	if (fs) {
		// filter only images
		for (let i = 0; i < fs.length; i++) {
			var f = fs[i];
			if (f.name.endsWith('.jpg') || f.name.endsWith('.jpeg') || f.name.endsWith('.png')) {
				files.push(f);
			}
		}
		for (let i = 0; i < files.length; i++) {
			var file = files[i];
			 imgFileName = files[i].name;
			 // console.log("imgfileName===",imgFileName);
			var reader = new FileReader();
			reader.onload = function (e) {
				var srcData = e.target.result;
				// console.log("srcData====",srcData);
				addThumbnail(srcData, i, imgFileName);
			};
			reader.readAsDataURL(file);
		}
	}
}

function clearThumbnails() {
	$("#thumbs").empty();
}

function addThumbnail(src, i, imgFileName) {
	 img = $("#thumbs").append("<li id='image-"+i+"' data-idx='"+i+"' ><img  src='"+src+"' crossOrigin='Anonymous' filename='"+imgFileName+"' /><span filename="+imgFileName+">"+imgFileName+"</span></li>");
	// var img1 = $('<img/>');
	// img1.attr({
	// 	'src': src,
	// 	// 'data-idx': i,
	// 	// 'id':i,
	// 	'imgfileName':imgFileName
	// });
	// img = $("#thumbs").append("<li id='image-"+i+"' data-idx='"+i+"' >",img1,'<br><span filename='+imgFileName+">"+imgFileName+"</span></li>");
}

//scroll
  // var counter=0;
  $(window).scroll(function () {
            if ($(window).scrollTop() == $(document).height() - $(window).height()) {
                // appendData();
            }
   });



function clearFields() {
	$('.clear-after-save').val('');
}

function onThumbnailClick(e) {
	// console.log("e=======", e);
	$('#canvas-container').html("Waiting For Image");
	$('#canvas-container').html("<canvas id='imgModifier'></canvas>");
	var canvas = new fabric.Canvas('imgModifier');
	var size = window.innerWidth;
	canvas.setHeight(size);
	canvas.setWidth(size);
	canvas.renderAll();
	img = e.currentTarget;
	// console.log("img======", img);
	var idx = $('li').attr('data-idx');
	imgId = $('li').attr('id');
	console.log("idx======", idx, "imgId+++++", imgId);
	selFile = files[idx];
	console.log("==========", selFile);
	// $( "div" ).text( $( "img" ).attr( "alt" ) );
	img.crossOrigin = "Anonymous";
	imgInstance = new fabric.Image(img, {
		left: 10,
		top: 10
	});
	canvas.add(imgInstance);
}

function saveImage() {
	var gstId = $("#gstId").val();
	var brandOwner = $("#brandOwner").val();
	var templateNo = $("#templateNo").val();
	var retailerId = $("#retailerId").val();
	var date = $("#date").val();
	var pageNo = $("#pageNo").val();
	var noOfLines = $("#noOfLines").val();
	var amount = $("#amount").val();
	if (gstId == '' || brandOwner == '' || templateNo == '' || retailerId == '' || date == '' || pageNo == '' || noOfLines == '') {
		alert('missing info in file name');
	} else {
		var fileName = gstId + "_" + brandOwner + "_" + templateNo + "_" + retailerId + "_" + date + "_" + pageNo + "_" + noOfLines + "_" + amount;
		$("#imgModifier").get(0).toBlob(function (blob) {
			saveAs(selFile, fileName + ".png")
		});
		clearFields();
		// clearThumbnails();

		$("#imgModifier").remove();
		$("#"+imgId).remove();
	}
}

function skipImage() {
	var gstId = $("#gstId").val();
	var brandOwner = $("#brandOwner").val();
	var templateNo = $("#templateNo").val();
	var retailerId = $("#retailerId").val();
	var date = $("#date").val();
	var pageNo = $("#pageNo").val();
	var noOfLines = $("#noOfLines").val();
	var amount = $("#amount").val();
	if (gstId == '' || brandOwner == '' || templateNo == '' || retailerId == '' || date == '' || pageNo == '' || noOfLines == '') {
		$("#imgModifier").get(0).toBlob(function(blob){
        saveAs(selFile)
      });
		$("#imgModifier").remove();
		$("#"+imgId).remove();
	} else {
		saveImage();
		
	}
}


function onGSTIDChange(e) {
	var gstId = $("#gstId").val();
	var gstSplit = gstId.split("_");
	if (gstSplit.length == 3) {
		// template name has been pasted
		$("#gstId").val(gstSplit[0]);
		$("#brandOwner").val(gstSplit[1]);
		$("#templateNo").val(gstSplit[2]);
	}
	// filter the templateData list and show template hints if any
	if (templateData) {
		var templateHints = templateData.filter(function (td) {
			return td[0] == gstId;
		});
		showHints(templateHints);
	}
}

function showHints(templateHints) {
	var hintsDiv = $('#hints');
	hintsDiv.empty();
	if (templateHints) {
		templateHints.forEach(th => {
			var hint = $('<span/>');
			hint.html(th.join('_'));
			hintsDiv.append(hint);
		});
	}
}
function setTemplate(e) {
	var templateName = $(e.currentTarget).text();
	tSplit = templateName.split('_');
	$("#gstId").val(tSplit[0]);
	$("#brandOwner").val(tSplit[1]);
	$("#templateNo").val(tSplit[2]);
}

window.onload = function () {
	$("#files").on('change', readFiles);
	$("#thumbs").on("click", "img", onThumbnailClick);
	$("#saveImage").on("click", saveImage);
	$("#skipImage").on("click", skipImage);
	$("#gstId").on("input", onGSTIDChange);
	$("#hints").on("click", 'span', setTemplate);

   
	// load csv
	CSV.fetch({
		url: templateDataPath
	}).done(function (dataset) {
		templateData = dataset.records;
	});

}

